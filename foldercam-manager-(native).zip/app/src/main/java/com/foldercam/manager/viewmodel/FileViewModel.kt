package com.foldercam.manager.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.foldercam.manager.model.FileItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.Stack

class FileViewModel : ViewModel() {

    private val _files = MutableLiveData<List<FileItem>>()
    val files: LiveData<List<FileItem>> = _files

    private var allFiles: List<FileItem> = emptyList()

    private val _currentPath = MutableLiveData<File>()
    val currentPath: LiveData<File> = _currentPath

    private val pathStack = Stack<File>()
    
    var showHidden = false
    var sortMode = SortMode.NAME

    enum class SortMode { NAME, DATE, SIZE }

    fun loadFiles(directory: File) {
        viewModelScope.launch(Dispatchers.IO) {
            val fileList = directory.listFiles()?.map { file ->
                FileItem(
                    file = file,
                    name = file.name,
                    isDirectory = file.isDirectory,
                    size = if (file.isDirectory) 0 else file.length(),
                    lastModified = file.lastModified(),
                    extension = file.extension.lowercase()
                )
            }?.filter { 
                if (showHidden) true else !it.name.startsWith(".")
            }?.let { list ->
                when (sortMode) {
                    SortMode.NAME -> list.sortedBy { it.name.lowercase() }
                    SortMode.DATE -> list.sortedByDescending { it.lastModified }
                    SortMode.SIZE -> list.sortedByDescending { it.size }
                }
            } ?: emptyList()
            
            allFiles = fileList
            _files.postValue(fileList)
            _currentPath.postValue(directory)
        }
    }

    fun filterFiles(query: String) {
        if (query.isEmpty()) {
            _files.value = allFiles
        } else {
            _files.value = allFiles.filter { it.name.contains(query, ignoreCase = true) }
        }
    }

    fun navigateTo(directory: File) {
        _currentPath.value?.let { pathStack.push(it) }
        loadFiles(directory)
    }

    fun navigateBack(): Boolean {
        if (pathStack.isNotEmpty()) {
            loadFiles(pathStack.pop())
            return true
        }
        return false
    }

    fun refresh() {
        _currentPath.value?.let { loadFiles(it) }
    }
}
