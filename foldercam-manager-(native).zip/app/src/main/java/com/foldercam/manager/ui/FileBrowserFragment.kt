package com.foldercam.manager.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.foldercam.manager.R
import com.foldercam.manager.databinding.DialogRenameBinding
import com.foldercam.manager.databinding.FragmentFileBrowserBinding
import com.foldercam.manager.model.FileItem
import com.foldercam.manager.util.FileManager
import com.foldercam.manager.viewmodel.FileViewModel
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import java.io.File

class FileBrowserFragment : Fragment() {

    private var _binding: FragmentFileBrowserBinding? = null
    private val binding get() = _binding!!

    private val viewModel: FileViewModel by viewModels()
    private lateinit var adapter: FileAdapter

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.all { it.value }) {
            loadInitialFiles()
        } else {
            Toast.makeText(requireContext(), "Permissions denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFileBrowserBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupToolbar()
        setupFab()
        checkPermissions()

        viewModel.files.observe(viewLifecycleOwner) {
            adapter.submitList(it)
        }

        viewModel.currentPath.observe(viewLifecycleOwner) {
            binding.toolbar.subtitle = it.absolutePath
        }
    }

    private fun setupRecyclerView() {
        adapter = FileAdapter(
            onFileClick = { item ->
                if (item.isDirectory) {
                    viewModel.navigateTo(item.file)
                } else {
                    openFile(item)
                }
            },
            onFileLongClick = { item ->
                showContextMenu(item)
            },
            onSelectionChanged = {}
        )
        updateLayoutManager()
        binding.recyclerView.adapter = adapter
    }

    private fun updateLayoutManager() {
        binding.recyclerView.layoutManager = if (adapter.isGridView) {
            GridLayoutManager(requireContext(), 3)
        } else {
            LinearLayoutManager(requireContext())
        }
    }

    private fun setupToolbar() {
        binding.toolbar.inflateMenu(R.menu.menu_browser)
        
        val searchItem = binding.toolbar.menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.filterFiles(newText ?: "")
                return true
            }
        })

        binding.toolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.action_new_folder -> {
                    showNewFolderDialog()
                    true
                }
                R.id.action_view_toggle -> {
                    adapter.isGridView = !adapter.isGridView
                    it.setIcon(if (adapter.isGridView) R.drawable.ic_list else R.drawable.ic_grid)
                    updateLayoutManager()
                    true
                }
                R.id.sort_name -> {
                    viewModel.sortMode = FileViewModel.SortMode.NAME
                    viewModel.refresh()
                    true
                }
                R.id.sort_date -> {
                    viewModel.sortMode = FileViewModel.SortMode.DATE
                    viewModel.refresh()
                    true
                }
                R.id.sort_size -> {
                    viewModel.sortMode = FileViewModel.SortMode.SIZE
                    viewModel.refresh()
                    true
                }
                else -> false
            }
        }
    }

    private fun showContextMenu(item: FileItem) {
        val options = arrayOf("Rename", "Delete", "Share")
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(item.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showRenameDialog(item)
                    1 -> showDeleteConfirm(item)
                    2 -> shareFile(item)
                }
            }
            .show()
    }

    private fun showRenameDialog(item: FileItem) {
        val input = TextInputEditText(requireContext())
        input.setText(item.name)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Rename")
            .setView(input)
            .setPositiveButton("Rename") { _, _ ->
                val newName = input.text.toString()
                if (newName.isNotEmpty() && FileManager.rename(item.file, newName)) {
                    viewModel.refresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteConfirm(item: FileItem) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete")
            .setMessage("Are you sure you want to delete ${item.name}?")
            .setPositiveButton("Delete") { _, _ ->
                if (FileManager.delete(item.file)) viewModel.refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun shareFile(item: FileItem) {
        val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", item.file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = if (item.isDirectory) "resource/folder" else "*/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share via"))
    }

    private fun openFile(item: FileItem) {
        val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", item.file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, requireContext().contentResolver.getType(uri) ?: "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "No app found to open this file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showNewFolderDialog() {
        val input = TextInputEditText(requireContext())
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("New Folder")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString()
                val currentPath = viewModel.currentPath.value
                if (name.isNotEmpty() && currentPath != null) {
                    if (FileManager.createFolder(currentPath, name)) viewModel.refresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setupFab() {
        binding.fabCamera.setOnClickListener {
            val currentPath = viewModel.currentPath.value?.absolutePath ?: return@setOnClickListener
            val action = FileBrowserFragmentDirections.actionFileBrowserFragmentToCameraFragment(currentPath)
            findNavController().navigate(action)
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
        }

        if (permissions.all { ContextCompat.checkSelfPermission(requireContext(), it) == PackageManager.PERMISSION_GRANTED }) {
            loadInitialFiles()
        } else {
            requestPermissionLauncher.launch(permissions.toTypedArray())
        }
    }

    private fun loadInitialFiles() {
        val root = Environment.getExternalStorageDirectory()
        viewModel.loadFiles(root)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
