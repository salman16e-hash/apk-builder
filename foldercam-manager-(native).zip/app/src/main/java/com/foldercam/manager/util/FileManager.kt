package com.foldercam.manager.util

import java.io.File

object FileManager {

    fun rename(file: File, newName: String): Boolean {
        val newFile = File(file.parent, newName)
        return file.renameTo(newFile)
    }

    fun delete(file: File): Boolean {
        return if (file.isDirectory) {
            file.deleteRecursively()
        } else {
            file.delete()
        }
    }

    fun createFolder(parent: File, name: String): Boolean {
        val newFolder = File(parent, name)
        return if (!newFolder.exists()) {
            newFolder.mkdirs()
        } else false
    }
}
