package com.foldercam.manager.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.foldercam.manager.R
import com.foldercam.manager.databinding.ItemFileGridBinding
import com.foldercam.manager.databinding.ItemFileListBinding
import com.foldercam.manager.model.FileItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FileAdapter(
    private val onFileClick: (FileItem) -> Unit,
    private val onFileLongClick: (FileItem) -> Unit,
    private val onSelectionChanged: () -> Unit
) : ListAdapter<FileItem, RecyclerView.ViewHolder>(FileDiffCallback()) {

    var isGridView = false
    var isSelectionMode = false

    override fun getItemViewType(position: Int): Int {
        return if (isGridView) 1 else 0
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == 1) {
            GridViewHolder(ItemFileGridBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        } else {
            ListViewHolder(ItemFileListBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = getItem(position)
        if (holder is ListViewHolder) holder.bind(item)
        else if (holder is GridViewHolder) holder.bind(item)
    }

    inner class ListViewHolder(private val binding: ItemFileListBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: FileItem) {
            binding.txtName.text = item.name
            val date = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(item.lastModified))
            binding.txtDetails.text = if (item.isDirectory) "Folder • $date" else "${formatSize(item.size)} • $date"
            
            val icon = when {
                item.isDirectory -> R.drawable.ic_folder
                item.extension in listOf("jpg", "jpeg", "png", "webp") -> R.drawable.ic_image
                item.extension in listOf("mp4", "webm") -> R.drawable.ic_video
                else -> R.drawable.ic_file
            }
            
            if (!item.isDirectory && item.extension in listOf("jpg", "jpeg", "png", "webp")) {
                Glide.with(binding.root).load(item.file).centerCrop().into(binding.imgIcon)
            } else {
                binding.imgIcon.setImageResource(icon)
            }

            binding.root.setOnClickListener { onFileClick(item) }
            binding.root.setOnLongClickListener { 
                onFileLongClick(item)
                true
            }
            binding.btnMore.setOnClickListener { onFileLongClick(item) }
        }
    }

    inner class GridViewHolder(private val binding: ItemFileGridBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: FileItem) {
            binding.txtName.text = item.name
            val icon = when {
                item.isDirectory -> R.drawable.ic_folder
                item.extension in listOf("jpg", "jpeg", "png", "webp") -> R.drawable.ic_image
                item.extension in listOf("mp4", "webm") -> R.drawable.ic_video
                else -> R.drawable.ic_file
            }

            if (!item.isDirectory && item.extension in listOf("jpg", "jpeg", "png", "webp")) {
                Glide.with(binding.root).load(item.file).centerCrop().into(binding.imgIcon)
            } else {
                binding.imgIcon.setImageResource(icon)
            }

            binding.root.setOnClickListener { onFileClick(item) }
            binding.root.setOnLongClickListener { 
                onFileLongClick(item)
                true
            }
        }
    }

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        return String.format("%.1f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
    }

    class FileDiffCallback : DiffUtil.ItemCallback<FileItem>() {
        override fun areItemsTheSame(oldItem: FileItem, newItem: FileItem) = oldItem.file.absolutePath == newItem.file.absolutePath
        override fun areContentsTheSame(oldItem: FileItem, newItem: FileItem) = oldItem == newItem
    }
}
