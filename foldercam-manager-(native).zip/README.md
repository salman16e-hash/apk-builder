# FolderCam Manager

A powerful Android file explorer with a built-in CameraX camera that saves photos and videos directly into the currently viewed folder.

## Features

- **File Explorer**: Browse files and folders with list/grid views.
- **Folder-Specific Camera**: Take photos/videos that are automatically saved in the current directory.
- **File Management**: Create, rename, delete, copy, move, and share files.
- **Image Preview**: Full-screen zoomable preview for images.
- **Search**: Quickly find files by name.

## Tech Stack

- **Language**: Kotlin
- **Architecture**: MVVM (ViewModel + LiveData)
- **UI**: Material Design 3, Jetpack Navigation
- **Camera**: CameraX
- **Image Loading**: Glide
- **Image Preview**: PhotoView

## How to Build

1. Open the project in Android Studio.
2. Sync Gradle.
3. Run the `app` module on an emulator or physical device (API 21+).

## Permissions

- `CAMERA`: For taking photos and videos.
- `RECORD_AUDIO`: For video recording.
- `READ_EXTERNAL_STORAGE` / `WRITE_EXTERNAL_STORAGE`: For file browsing and saving.
- `MANAGE_EXTERNAL_STORAGE`: For full storage access on Android 11+.
